SELECT notes
FROM capture_images
WHERE serial_number = :serial_number AND capture_position = :capture_position
ORDER BY id DESC
LIMIT 1