SELECT event_value, x, y, z, result FROM capture_images 
WHERE serial_number = :GroupID AND  capture_position = :Position 
ORDER BY id desc
LIMIT 1