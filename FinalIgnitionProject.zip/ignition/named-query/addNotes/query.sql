UPDATE capture_images
SET notes = :notes
WHERE serial_number = :serial_number AND capture_position = :capture_position