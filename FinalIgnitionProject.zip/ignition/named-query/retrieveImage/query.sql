SELECT img_blob FROM capture_images 
WHERE  serial_number  = :UUID AND capture_position = :positionNum 