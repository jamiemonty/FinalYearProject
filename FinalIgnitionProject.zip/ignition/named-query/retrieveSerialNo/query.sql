SELECT
  serial_number,
  MAX(capture_ts) AS last_capture_ts
FROM capture_images
WHERE serial_number IS NOT NULL
AND (
    :startTime IS NULL OR :startTime = ''
    OR capture_ts >= CASE WHEN :startTime = '' THEN NULL ELSE :startTime END
)
AND (
    :endTime IS NULL OR :endTime = ''
    OR capture_ts <= CASE WHEN :endTime = '' THEN NULL ELSE :endTime END
)
GROUP BY serial_number
ORDER BY last_capture_ts DESC;