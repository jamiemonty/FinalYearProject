UPDATE capture_images
SET result = :result
WHERE serial_number = :serial_number AND capture_position = :capture_position
