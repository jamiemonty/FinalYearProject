SELECT
  capture_group_id,
  MAX(capture_ts) AS last_capture_ts
FROM capture_images
WHERE capture_group_id IS NOT NULL
GROUP BY capture_group_id
HAVING COUNT(*) = 3
ORDER BY last_capture_ts DESC;