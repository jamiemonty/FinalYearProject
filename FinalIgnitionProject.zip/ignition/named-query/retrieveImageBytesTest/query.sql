SELECT img_blob FROM capture_images
WHERE id = 118