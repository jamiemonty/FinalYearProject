from java.net import URL
from java.io import BufferedInputStream, ByteArrayOutputStream
from java.util import Base64
from java.lang import String
from jarray import zeros


def _basic_auth_header(username, password):
    token = "%s:%s" % (username, password)
    # Convert to Java String for getBytes()
    b64 = Base64.getEncoder().encodeToString(String(token).getBytes("UTF-8"))
    return "Basic " + b64

def _debug_log(msg):
	#safe logging helper
	system.util.getLogger("SV600HTTP").info(msg)
	
def download_with_basic_auth_follow_redirects(url_str, auth_header, timeout_ms=15000, max_redirects=5):
	"""
	Get url_str, ensuring Auth header is present even after redirects.
	Returns (responseCode, contentType, contentDisposition, byte[] content)
	"""
	current_url = url_str
	redirects = 0
	while True:
		_debug_log("Requesting: %s (redirects=%s)" % (current_url, redirects))
		url = URL(current_url)
		conn = url.openConnection()
		#configure connection
		try:
			conn.setConnectTimeout(timeout_ms)
			conn.setReadTimeout(timeout_ms)
		except: 
			pass
		if auth_header:
			conn.setRequestProperty("Authorization", auth_header)
		
		conn.setRequestProperty("Accept", "*/*")
		conn.setRequestProperty("User-Agent", "Ignition/Project-SV600-Agent")
		#Prevent automatic redirect handling if available so I can reapply auth 
		try:
			conn.setInstanceFollowRedirects(False)
		except:
			pass
			
		#connect and get a response
		code = conn.getResponseCode()
		_debug_log("HTTP response code: %s" % code)
		#If redirect, get Location and loop, resending auth header
		if code in (301, 302, 303, 307, 308) and redirects < max_redirects:
			location = conn.getHeaderField("Location")
			_debug_log("Redirect location: %s" % str(location))
			if not location:
				raise Exception("Redirect with Location header (HTTP %s)" % code)
			#Resolve the relative redirects
			current_url = URL(URL(current_url), location).toString()
			redirects += 1
			try:
				conn.disconnect()
			except:
				pass
			continue
			
		if code >= 400:
			try:
				err_stream = conn.getErrorStream()
				err_text = system.util.readAll(err_stream) if err_stream else None
				if err_stream:
					err_stream.close()
			except:
				err_text = None
			try:
				conn.disconnect()
			except:
				pass
			raise Exception("HTTP %s error. Body: %s" % (code, str(err_text)))
			
		#Success will read the headers and bytes
		content_type = conn.getContentType()
		content_disp = conn.getHeaderField("Content-Disposition")
		in_stream = BufferedInputStream(conn.getInputStream())
		baos = ByteArrayOutputStream()
		buf = zeros(4096, 'b')
		while True:
			n = in_stream.read(buf, 0, len(buf))
			if n == -1:
				break
			baos.write(buf, 0, n)
		in_stream.close()
		try: 
			conn.disconnect()
		except:
			pass
		return code, content_type, content_disp, baos.toByteArray()
		
def capture_image_and_store(ip_address, username, password, device_name="SV600", db_table="capture_images", capture_position = None, capture_group_id = None, serial_number = None):
	"""
	Captures an image from the SV600 and saves to DB.
	Returns a dict of results for Perspective.
	"""
	url = "http://%s:9011/data/soundsurface/0/capture?captureFormat=Jpeg&frequencyVisualization=Spectrum&showDBMarker=true" % (ip_address)
	
	auth_header = _basic_auth_header(username, password)
	try:
		code, content_type, content_disp, img_bytes = download_with_basic_auth_follow_redirects(url, auth_header)
		if code == 200 and img_bytes:
			#Store to DB
			sql = "INSERT INTO capture_images (device_name, surface_id, capture_ts, content_type, img_blob, capture_position, capture_group_id, serial_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?)" 
			params = [device_name, 0, system.date.now(), content_type, img_bytes, capture_position, capture_group_id, serial_number]
			capture_image_id = system.db.runPrepUpdate(sql, params, getKey=1)
			return {
				"success": True,
				"message": "Image captured and saved",
				"capture_image_id": capture_image_id,
				"bytes": len(img_bytes),
				"content_type": content_type
			}
		else:
			return {"success": False, "message": "Failed HTTP result: %s" % code}
	except Exception as e:
		_debug_log("Capture/store failed: %s" % str(e))
		return {"success": False, "message": str(e)}



def fetch_latest_event_metadata(ip_address, event_id, username, password, amount=10, duration_ns=1000000000, timeout_ms=15000):
	#Fetch the latest event results and return event_id, evetn_value , and the xyz coordinates
	url_str = "http://%s:9011/data/event/%s?duration=%s&amount=%s" % (ip_address, event_id, duration_ns, amount)
	auth_header = _basic_auth_header(username, password)
	
	code, content_type, content_disp, body_bytes = download_with_basic_auth_follow_redirects(url_str, auth_header, timeout_ms=timeout_ms)
	
	if code != 200:
		raise Exception("Event metadata failed HTTP %s" % code)
		
	body_text = String(body_bytes, "UTF-8")
	data = system.util.jsonDecode(body_text)
	
	if not data:
		return None
		
	# Pick newest by timestamp (string compare works fine for ISO timestamps)
	newest = max(data, key=lambda r: r.get("timestamp", ""))

	loc0 = (newest.get("locations") or [{}])[0]
	val0 = (newest.get("values") or [None])[0]

	return {
		"event_id": newest.get("id"),
		"event_value": float(val0) if val0 is not None else None,
		"x": float(loc0.get("x")) if loc0.get("x") is not None else None,
		"y": float(loc0.get("y")) if loc0.get("y") is not None else None,
		"z": float(loc0.get("z")) if loc0.get("z") is not None else None
	}
	
def update_capture_row_with_metadata(capture_image_id, meta, db_table="capture_images", fail_db_threshold= 10.0):
	# Evaluate pass/fail (assuming event_value is dB, and higher than threshold = FAIL)
	event_value = meta.get("event_value")
	
	if event_value is None:
		result = "UNKNOWN"
	elif event_value >= fail_db_threshold:
		result = "FAIL"
	else:
		result = "PASS"
	
	sql="""
	UPDATE %s
	SET event_id = ?, event_value = ?, x = ?, y = ?, z = ?, result = ?
	WHERE id = ?
	""" % db_table
	
	params = [
		meta.get("event_id"),
		meta.get("event_value"),
		meta.get("x"),
		meta.get("y"),
		meta.get("z"),
		result,
		capture_image_id
	]
	return system.db.runPrepUpdate(sql, params)