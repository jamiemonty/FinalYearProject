def decode_qr_from_db_row(row_id):
    import system
    from java.io import ByteArrayInputStream
    from javax.imageio import ImageIO
    from com.google.zxing import MultiFormatReader, NotFoundException, BinaryBitmap
    from com.google.zxing.common import HybridBinarizer
    from com.google.zxing.client.j2se import BufferedImageLuminanceSource
    from com.google.zxing import DecodeHintType
    from java.util import Hashtable

    img_blob = system.db.runScalarQuery("SELECT img_blob FROM capture_images WHERE id = %d" % int(row_id))
    if img_blob is None:
        system.util.getLogger("QRLib").warn("No blob for id=%s" % row_id)
        return None

    try:
        stream = ByteArrayInputStream(img_blob)
        buffered = ImageIO.read(stream)
        if buffered is None:
            system.util.getLogger("QRLib").warn("ImageIO could not read bytes for id=%s" % row_id)
            return None

        source = BufferedImageLuminanceSource(buffered)
        bitmap = BinaryBitmap(HybridBinarizer(source))
        reader = MultiFormatReader()
        hints = Hashtable()
        hints.put(DecodeHintType.TRY_HARDER, True)

        try:
            res = reader.decode(bitmap, hints)
            value = res.getText()
            system.util.getLogger("QRLib").info("Decoded QR for row %s: %s" % (row_id, value))
            return value
        except NotFoundException:
            system.util.getLogger("QRLib").warn("No QR/barcode found in blob for id=%s" % row_id)
            return None
    except Exception as e:
        system.util.getLogger("QRLib").error("Error in decode_qr_from_db_row: %s" % e)
        return None